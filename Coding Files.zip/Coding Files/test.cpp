/*
 * SNHU: CS-405 Secure Coding
 * Module Four Assignment
 * Test.cpp : This file contains the Google Tests to be run.
 * Author: Matthew Bandyk
 * Version: 1.0
 * Updated: 11/18/2023
 * NOTES: Created the positive and negative tests that will be run
*/

// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL();
//}

// Test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());

    // Add a single value to the collection
    collection->push_back(18);

    // The size must be 1
    ASSERT_EQ(collection->size(), 1);
}

// Test to verify adding five values to the collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);

    // Check the size after adding 5 values
    ASSERT_EQ(collection->size(), 5);
}

// Test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualToSize)
{
    // Check for 0 entries
    ASSERT_GE(collection->max_size(), 0);

    // Add 1 entry (total 1)
    add_entries(1);
    ASSERT_GE(collection->max_size(), collection->size());

    // Add 4 more entries (total 5)
    add_entries(4);
    ASSERT_GE(collection->max_size(), collection->size());

    // Add 5 more entries (total 10)
    add_entries(5);
    ASSERT_GE(collection->max_size(), collection->size());
}

// Test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityGreaterThanOrEqualToSize)
{
    // Check for 0 entries
    ASSERT_GE(collection->capacity(), 0);

    // Add 1 entry
    add_entries(1);
    ASSERT_GE(collection->capacity(), collection->size());

    // Add 4 more entries (total 5)
    add_entries(4);
    ASSERT_GE(collection->capacity(), collection->size());

    // Add 5 more entries (total 10)
    add_entries(5);
    ASSERT_GE(collection->capacity(), collection->size());
}

// Test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
    // Resize to 10
    collection->resize(10);
    ASSERT_EQ(collection->size(), 10);
}

// Test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
    // Add 10 entries
    add_entries(10);

    // Resize to 5
    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);
}

// Test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeDecreasesToZero)
{
    // Add 10 entries
    add_entries(10);

    // Resize to 0
    collection->resize(0);
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    // Add 10 entries
    add_entries(10);

    // Clear the collection
    collection->clear();
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify erase(begin, end) erases the collection
TEST_F(CollectionTest, EraseBeginEndErasesCollection)
{
    // Add 10 entries
    add_entries(10);

    // Erase the entire collection
    collection->erase(collection->begin(), collection->end());
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacity)
{
    // Reserve space for 100 elements
    collection->reserve(100);

    // The size should remain 0
    ASSERT_EQ(collection->size(), 0);

    // The capacity should be at least 100
    ASSERT_GE(collection->capacity(), 100);
}

// Test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, OutOfRangeExceptionThrown)
{
    // Add 5 entries
    add_entries(5);

    // Access an out-of-range index (e.g., index 10)
    ASSERT_THROW(collection->at(10), std::out_of_range);
}

// Positive test
// Test to verify that insert in the beginning of the collection works
TEST_F(CollectionTest, InsertInFrontOfCollection)
{
    // Add some initial entries to the collection
    add_entries(3);

    // Insert an entry at the front of the collection
    collection->insert(collection->begin(), 42);

    // Verify that the first element is now 42
    ASSERT_EQ(collection->at(0), 42);
}

// Negative test - 
// Testing exception thrown if attempt to resize vector to size less than 0
TEST_F(CollectionTest, ResizeToNegativeSize)
{
    // Ensure the vector is empty initially
    ASSERT_TRUE(collection->empty());

    // Attempt to resize the vector to a negative size
    ASSERT_THROW(collection->resize(-1), std::length_error);
}