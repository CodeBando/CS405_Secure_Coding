/*
 * SNHU: CS-405 Secure Coding
 * Module Four Assignment
 * Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
 * Author: Matthew Bandyk
 * Version: 1.0
 * Updated: 11/17/2023
 * NOTES: Updated code base to execute multiple exception handlers
*/

#include <iostream>
#include <stdexcept>

/*
* Created custom exception class derived from std::exception.
* This exception will be utilized to address any specific exceptions that are thrown.
* When caught, it provides a descriptive message using the what() method.
*/
class CustomException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Details regarding exception would be added here";
    }
};

// Updated code to address the ask to throw any standard exception
bool do_even_more_custom_application_logic()
{
    // Throwing a standard exception
    throw std::runtime_error("Exception thrown when doing custom logic");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Exception handler
    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }

    catch (const std::exception& e) {
        // Catching and displaying a standard exception message utilizing the what() method to pull in the exception details
        std::cout << "Standard Exception: " << e.what() << std::endl;
    }

    // throwing custom exception to be handled in main
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    if (den == 0.0f)
    {
        // Throwing a standard exception for divide by zero errors
        throw std::invalid_argument("Can not complete a division by zero");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    //  Exception Handler to capture exception from divide() method
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& e) {
        // Catching and displaying a standard exception thrown from divide method
        std::cout << "Standard Exception: " << e.what() << std::endl;
    }
}

int main()
{
    // Exception handler wrapping entire main function, captures custom, standard, and uncaught exceptions as needed
    try {
        std::cout << "Exceptions Tests!" << std::endl;
        do_division();
        do_custom_application_logic(); // This line throws a custom exception.
    }
    
    catch (const CustomException& ce) {
        // Catching and displaying the custom exception
        std::cout << "Caught Custom Exception: " << ce.what() << std::endl;
    }

    catch (const std::exception& e) {
        // Catching and displaying a standard exception
        std::cout << "Caught Standard Exception: " << e.what() << std::endl;
    }
    
    catch (...) {
        // Catching uncaught exceptions
        std::cout << "Uncaught Exception: issue occurred" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu