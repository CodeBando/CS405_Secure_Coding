/*
 * SNHU: CS-405 Secure Coding
 * Module Two Assignment
 * BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
 * Author: Matthew Bandyk
 * Version: 1.0
 * Updated: 11/04/2023
 * NOTES: Updated main function to prevent Buffer Overflow
		  Utilize getline, limiting characters captured
 *        Informs user that input value can only be 19 characters if they did
 *             user_input[20] - 1; for strings ending null pointer
 */
 


#include <iomanip>
#include <iostream>

/*
* Updated Main Function
* Updated cin statement to cin.getline
* Utilizes size of user_input to only capture what the buffer can hold
* checks size of user input, reacting accordinly
*/
int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	const std::string account_number = "CharlieBrown42";
	char user_input[20];

	std::cout << "Enter a value: ";
	
	// updated cin to utilize cin.getline, taking user_input up to the 19th character only
	// This ensures that the size of the input captured does not exceed the 20 char limit assigned to the varable  
	std::cin.getline(user_input, sizeof(user_input));

	// if input was greater than 19 characters, print only 19 characters can be used, user input captured, and account number
	if (sizeof(user_input) > 20) {
		std::cout << "NOTE: only 19 characters can be entered " << std::endl;
		std::cout << "You entered: " << user_input << std::endl;
		std::cout << "Account Number = " << account_number << std::endl;
	}
	// else display input value and account number
	else {
		std::cout << "You entered: " << user_input << std::endl;
		std::cout << "Account Number = " << account_number << std::endl;
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
