/*
 * SNHU: CS-405 Secure Coding
 * Module Four Assignment
 * CS405_Encryption_Bandyk_M.cpp : This file contains the 'main' function. Program execution begins and ends there.
 * Author: Matthew Bandyk
 * Version: 1.0
 * Updated: 11/20/2023
 * NOTES: Updated code base to read file, execute XOR encryption/decryption, and write to files
*/

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>

// Fuction to perform XOR encryption/decryption on a source string using a key
// @params source: The data to be encrypted/decrypted
//         key: Key to be used in encryption/decryption
// @return output: the transformed string (encrypted or decrypted)
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // Get the lengths of the key and source strings
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    // Initialize the output string with the same content as the source
    std::string output = source;

    // loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i)
    { // XOR each character with the corresponding character from the key using modulo for cycling
        output[i] = source[i] ^ key[i % key_length];
    }

    // Output length must equal our source length
    assert(output.length() == source_length);

    // return the transformed string
    return output;
}

// Function to read the content of a file into a string
// @return file_text: string of file contents
std::string read_file(const std::string& filename)
{
    // Variable to hold the content of the file in a string
    std::string file_text;

    // Open the file for reading
    std::ifstream file(filename);

    // Validate file is open
    if (file.is_open())
    {
        // Read the entire file into the file_text string
        std::ostringstream oss;
        oss << file.rdbuf();
        file_text = oss.str();

        // Close the file
        file.close();
    }
    // If file didn't open
    else
    {
        std::cerr << "Error: Unable to open file: " << filename << std::endl;
    }

    return file_text;
}

// Function to extract the student name from the string of data
// @params string_data: string holding all data from the file
// @return student_name: student name pulled from the string of data
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos)
    { // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

// Function to write data to file
// @params filename: name of file to create
//         student_name: the students name to write to file
//         key: the key used for encryption/decryption
//         data: string of data pulled from file to be written to new file
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    // Open the file for writing
    std::ofstream file(filename);

    // Validate file is open
    if (file.is_open())
    {
        // Write student name to the file
        file << student_name << std::endl;

        // Get the current timestamp
        time_t current_time = std::time(nullptr);
        tm time_info;
        localtime_s(&time_info, &current_time);

        // Write timestamp (yyyy-mm-dd) to the file
        file << std::put_time(&time_info, "%Y-%m-%d") << std::endl;

        // Write the key used to the file
        file << key << std::endl;

        // Write data to the file
        file << data << std::endl;

        // Close the file
        file.close();
    }
    // Else issue creating and opening file for writing
    else
    {
        std::cerr << "Error: Unable to open file for writing: " << filename << std::endl;
    }
}

// One and only main function
int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    // File names for input, encrypted, and decrypted data
    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";

    // Read input file
    const std::string source_string = read_file(file_name);

    // Encryption key
    const std::string key = "sliver";

    // get the student name from the data file
    const std::string student_name = get_student_name(source_string);

    // encrypt sourceString with key
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // save encrypted_string to file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // decrypt encryptedString with key
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // save decrypted_string to file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
